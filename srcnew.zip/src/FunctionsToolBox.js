import React from 'react';



class FunctionsToolBox extends React.Component {
    render() {
      return (
        <div className='FunctionsToolBox'>
          FunctionsToolBox
        </div>
      );
    }
  }



export default FunctionsToolBox;