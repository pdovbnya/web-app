import React from "react";
import "./fancy.scss";
import "./App.css";
import ReactTooltip from "react-tooltip";
import Calendar from "./widgets/Calendar.js";
import ComboMBS from "./widgets/ComboMBS.js";

import BondChart from "./charts/BondChart.js";

import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const StartEstimationButton = withStyles({
  root: {
    background:
      "linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(47, 68, 78, 0.7) 100%, rgba(139, 197, 64, 0.8) 100%);",
    borderRadius: 3,
    border: 0,
    position: "absolute",
    color: "white",
    height: "15%",
    width: "33%",
    top: "40%",
    left: "16%",
    boxShadow: "0 3px 5px 2px rgba(255, 105, 135, .3)"
  },
  label: {
    textTransform: "none",
    fontSize: "1.2rem"
  }
})(Button);

class MBSToolBox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      makeQueryStateActive: true
    };
  }

  sendQuery() {
    this.setState({ makeQueryStateActive: false });
  }

  render() {
    let renderSheet = undefined;

    if (this.state.makeQueryStateActive) {
      renderSheet = (
        <div>
          <ComboMBS />
          <Calendar />
          <StartEstimationButton onClick={this.sendQuery.bind(this)}>
            Начать расчёт
          </StartEstimationButton>
        </div>
      );
    } else {
      renderSheet = (
        <BondChart
          dataHist={this.props.data.CPR.dataHist}
          dataReal={this.props.data.CPR.dataReal}
          dataBase={this.props.data.CPR.dataBase}
          container={this.props.container}
        />
      );
    }

    return (
      <div className="MBSToolBox">
        <span
          className="close black fat"
          data-tip="Закрыть"
          onClick={() =>
            this.props.interface.onCloseMBSToolBox(this.props.boxId)
          }
        ></span>
        <ReactTooltip
          className="tooltip"
          place="bottom"
          effect="solid"
          delayShow={500}
        />

        {renderSheet}
      </div>
    );
  }
}

export default MBSToolBox;
