import React from "react";
import PropTypes from "prop-types";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import { createMuiTheme } from "@material-ui/core";
import { ThemeProvider } from "@material-ui/styles";

const macroTabsTheme = createMuiTheme({
  overrides: {
    MuiAppBar: {
      root: {
        position: "absolute",
        width: "100%",
        height: "11.5%"
      },
      positionStatic: {
        position: "absolute",
        width: "100%",
        height: "11.5%"
      }
    },
    MuiTab: {
      root: {
        height: "auto",
        minHeight: "auto !important",
        minWidth: "auto !important",
        fontSize: "0.52rem",
        ///////////////////////////////////////////////////////
        "@media (min-height:1px)": {
          fontSize: "0.52rem",
          padding: "1% 3%"
        },
        "@media (min-height:570px)": {
          fontSize: "0.57rem",
          padding: "1% 3%"
        },
        "@media (min-height:600px)": {
          fontSize: "0.6rem",
          padding: "1% 3%"
        },
        "@media (min-height:640px) and (max-width:1430px)": {
          fontSize: "0.6rem",
          padding: "1.2% 3%"
        },
        "@media (min-height:640px) and (min-width:1430px)": {
          fontSize: "0.65rem",
          padding: "1% 3%"
        },
        "@media (min-height:700px) and (max-width:1430px)": {
          fontSize: "0.6rem",
          padding: "2% 3%"
        },
        "@media (min-height:700px) and (min-width:1430px)": {
          fontSize: "0.7rem",
          padding: "1% 3%"
        },
        "@media (min-height:760px) and (min-width:1430px)": {
          fontSize: "0.7rem",
          padding: "2% 3%"
        }
      }
    },
    MuiTabs: {
      root: {
        minHeight: "auto !important",
        "@media (min-width:600px)": {
          minHeight: "auto !important"
        }
      },
      flexContainer: {
        height: "auto"
      }
    }
  }
});

class MacroTabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: 0
    };
  }

  render() {
    let handleChange = (event, newValue) => {
      this.setState({ value: newValue });
      this.props.interface.onChangeTab(newValue);
    };

    return (
      <div>
        <ThemeProvider theme={macroTabsTheme}>
          <AppBar position="static" color="default">
            <Tabs
              value={this.state.value}
              onChange={handleChange}
              indicatorColor="primary"
              textColor="primary"
              variant="fullWidth"
              aria-label="full width tabs example"
            >
              <Tab label="КБД" {...a11yProps(0)} />
              <Tab label="Короткая ставка" {...a11yProps(1)} />
              <Tab label="МосПрайм-6" {...a11yProps(2)} />
              <Tab label="Ипотечная ставка" {...a11yProps(3)} />
              <Tab label="Индекс цен на недвижимость" {...a11yProps(4)} />
            </Tabs>
          </AppBar>
        </ThemeProvider>
      </div>
    );
  }
}

function TabPanel(props) {
  const { children, value, index } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired
};

function a11yProps(index) {
  return {
    id: `full-width-tab-${index}`,
    "aria-controls": `full-width-tabpanel-${index}`
  };
}

export default MacroTabs;
