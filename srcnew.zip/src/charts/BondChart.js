import React from "react";

let todayYear = new Date().getFullYear();
let todayMonth = new Date().getMonth();
const Highcharts = window.Highcharts;

class BondChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  chartRenderer() {
    this.instance = Highcharts.chart({
      chart: {
        type: "line",
        renderTo: this.props.container,
        zoomType: "x",
        resetZoomButton: {
          theme: {
            display: "none"
          }
        },
        selectionMarkerFill: "rgba(131, 173, 75, 0.12)",
        plotBorderWidth: 1,
        marginLeft: 27
      },

      plotOptions: {
        series: {
          states: {
            hover: {
              enabled: false
            }
          }
        }
      },

      series: [
        {
          name: "",
          data: this.props.dataReal,
          color: "rgba(47, 68, 78, 1)",
          marker: {
            lineColor: "rgba(47, 68, 78, 0.7)",
            fillColor: "rgba(166, 233, 78, 0.945)",
            radius: 2,
            enabled: false
          },
          animation: {
            duration: 400
          },
          index: 100,
          states: {
            inactive: {
              opacity: 1
            }
          }
        },
        {
          name: "",
          data: this.props.dataBase,
          color: "rgb(180, 180, 180)",
          dashStyle: "shortdash",
          // lineWidth: 1,
          animation: {
            duration: 0
          },
          marker: {
            enabled: false
          },
          index: 0,
          states: {
            inactive: {
              opacity: 1
            }
          }
          // enableMouseTracking: false
        },
        {
          data: this.props.dataHist,
          color: "green",
          animation: {
            duration: 0
          },
          states: {
            inactive: {
              opacity: 1
            }
          },
          lineWidth: 1.3
          // enableMouseTracking: false
        }
      ],

      title: {
        text: ""
      },

      xAxis: {
        type: "datetime",
        gridLineDashStyle: "dash",
        gridLineWidth: 1,
        maxPadding: 0.003,
        minPadding: 0.003,
        min: this.props.xMin,
        max: this.props.xMax,
        plotBands: [
          {
            from: 1299999900000,
            to: new Date(todayYear, todayMonth).valueOf(),
            color: "rgba(47, 68, 78, 0.06)"
          }
        ]
      },

      yAxis: {
        title: "",
        allowDecimals: true,
        gridLineDashStyle: "dash",
        labels: {
          x: -8,
          format: "{value:.2f}"
        },
        startOnTick: false,
        endOnTick: false
      },

      legend: {
        enabled: false
      },

      credits: {
        enabled: false
      },

      tooltip: {
        // animation: true,
        enabled: false,
        // split: true,
        valueDecimals: 2,
        useHTML: true,
        headerFormat: '<span style="font-size: 11px">{point.key}</span><br/>',
        pointFormat:
          '<span style="font-size: 12px; font-weight: 1000">{point.y}</span>'
      }
    });
  }

  componentDidMount() {
    this.chartRenderer();
  }

  componentDidUpdate() {
    this.chartRenderer();
  }

  render() {
    return (
      <div>
        <div id={this.props.container}></div>
      </div>
    );
  }
}

export default BondChart;
