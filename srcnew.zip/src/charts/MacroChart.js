import React from "react";

const Highcharts = window.Highcharts;
Highcharts.setOptions({
  lang: {
    loading: "Подождите...",
    months: [
      "Январь",
      "Февраль",
      "Март",
      "Апрель",
      "Май",
      "Июнь",
      "Июль",
      "Август",
      "Сентябрь",
      "Октябрь",
      "Ноябрь",
      "Декабрь"
    ],
    shortMonths: [
      "янв",
      "фев",
      "март",
      "апр",
      "май",
      "июнь",
      "июль",
      "авг",
      "сент",
      "окт",
      "нояб",
      "дек"
    ],
    resetZoom: "Отменить выделение"
  }
});

let todayYear = new Date().getFullYear();
let todayMonth = new Date().getMonth();

class MacroChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // drawingIsHappening: false,
      // drawnData: []
    };
    this.drawingIsHappening = false;
    this.drawnData = [];
  }

  chartRenderer() {
    this.instance = Highcharts.chart({
      chart: {
        type: "line",
        renderTo: "containerMacroChart",
        zoomType:
          this.props.drawingRegime || this.props.seriesIndex === 0
            ? undefined
            : "x",
        resetZoomButton: {
          theme: {
            display: "none"
          }
        },
        selectionMarkerFill: "rgba(131, 173, 75, 0.12)",
        plotBorderWidth: 1,
        marginLeft: 27
      },

      plotOptions: {
        series: {
          states: {
            hover: {
              enabled: this.props.drawingRegime ? false : true
            }
          }
        }
      },

      // mapNavigation: {
      //   enabled: true,
      //   enableButtons: false
      // },

      series: [
        {
          name: "",
          data: this.props.dataReal,
          color: "rgba(47, 68, 78, 1)",
          marker: {
            lineColor: "rgba(47, 68, 78, 0.7)",
            fillColor: "rgba(166, 233, 78, 0.945)",
            radius: 2,
            enabled: false
          },
          animation: {
            duration: this.props.drawingRegime ? 0 : 400
          },
          index: 100,
          states: {
            inactive: {
              opacity: this.props.drawingRegime ? 1 : 0.2
            }
          }
        },
        {
          name: "",
          data: this.props.dataBase,
          color: "rgb(180, 180, 180)",
          dashStyle: "shortdash",
          lineWidth: 1,
          animation: {
            duration: 0
          },
          marker: {
            enabled: false
          },
          index: 0,
          states: {
            inactive: {
              opacity: 1
            }
          },
          enableMouseTracking: false
        },
        {
          data: [],
          color: "#F31414",
          animation: {
            duration: 0
          },
          states: {
            inactive: {
              opacity: 1
            }
          },
          dashStyle: "ShortDot",
          lineWidth: 1.3,
          enableMouseTracking: false
        }
        // {
        //   data: [],
        //   type: "scatter",
        //   animation: {
        //     duration: 0
        //   },
        //   marker: {
        //     symbol: "circle",
        //     radius: 1.5,
        //     fillColor: "rgb(255, 77, 77)",
        //     lineColor: "rgb(255, 26, 26)",
        //     lineWidth: 0.6
        //   }
        // }
      ],

      title: {
        text: ""
      },

      xAxis: {
        type: "datetime",
        gridLineDashStyle: "dash",
        gridLineWidth: 1,
        maxPadding: 0.003,
        minPadding: 0.003,
        min: this.props.xMin,
        max: this.props.xMax,
        plotBands: [
          {
            from: 1299999900000,
            to: new Date(todayYear, todayMonth).valueOf(),
            color: "rgba(47, 68, 78, 0.06)"
          }
        ],
        crosshair: this.props.drawingRegime ? { snap: false } : false,
        events: {
          afterSetExtremes: function(event) {
            this.props.setXminmax(event.min, event.max);
            if (
              (event.min > this.props.xMin || event.max < this.props.xMax) &&
              !this.props.drawingRegime
            ) {
              this.props.changeZoomState();
            }
          }.bind(this)
        }
      },

      yAxis: {
        title: "",
        allowDecimals: false,
        gridLineDashStyle: "dash",
        labels: {
          x: -8,
          format: "{value:.f}"
        },
        max:
          this.props.oldYmax !== undefined
            ? this.props.oldYmax
            : Math.max(
                this.props.dataBaseMax +
                  (this.props.dataBaseMax - this.props.dataBaseMin) * 0.05,
                this.props.dataRealMax +
                  (this.props.dataRealMax - this.props.dataRealMin) * 0.05
              ),
        min:
          this.props.oldYmin !== undefined
            ? this.props.oldYmin
            : Math.min(
                this.props.dataBaseMin -
                  (this.props.dataBaseMax - this.props.dataBaseMin) * 0.05,
                this.props.dataRealMin -
                  (this.props.dataRealMax - this.props.dataRealMin) * 0.05
              ),
        startOnTick: false,
        endOnTick: false,
        crosshair: this.props.drawingRegime ? { snap: false } : false
      },

      legend: {
        enabled: false
      },

      credits: {
        enabled: false
      },

      tooltip: {
        animation: this.props.drawingRegime ? false : true,
        enabled: this.props.drawingRegime ? false : true,
        valueDecimals: 2,
        useHTML: true,
        headerFormat: '<span style="font-size: 11px">{point.key}</span><br/>',
        pointFormat:
          '<span style="font-size: 12px; font-weight: 1000">{point.y}</span>'
      }
    });
  }

  componentDidMount() {
    this.chartRenderer();
  }

  componentDidUpdate() {
    this.chartRenderer();
  }

  onMouseDown(e) {
    if (this.props.drawingRegime) {
      this.drawingIsHappening = true;
    }
  }

  onMouseMove(e) {
    let chart = this.instance;
    e = chart.pointer.normalize(e);

    let xValue = chart.xAxis[0].toValue(e.chartX);
    let yValue = chart.yAxis[0].toValue(e.chartY);

    // if (this.props.drawingRegime) {
    //   chart.series[3].removePoint(0);
    //   chart.series[3].addPoint([xValue, yValue], true, false, false, false);
    // }

    if (this.drawingIsHappening) {
      if (yValue > 24) {
        chart.yAxis[0].update({
          max: 25
        });
      }

      if (
        this.props.dataBase[0][0] - 2700000000 <= xValue &&
        xValue <=
          this.props.dataBase[this.props.dataBase.length - 1][0] + 2700000000 &&
        yValue >= chart.yAxis[0].min &&
        yValue <= chart.yAxis[0].max
      ) {
        if (
          this.drawnData.length === 0 ||
          xValue > this.drawnData[this.drawnData.length - 1][0]
        ) {
          this.drawnData.push([xValue, yValue]);
          chart.series[2].addPoint([xValue, yValue], true, false, false, false);
        }
      }
    }
  }

  onMouseUp(e) {
    if (this.props.drawingRegime) {
      this.drawingIsHappening = false;
      this.props.drawHandler(this.drawnData);
      if (
        !this.props.drawingHasBeenMadeOnChart &&
        this.drawnData.length !== 0
      ) {
        this.props.setDrawingState();
      }
      this.instance.series[2].setData([], false);
      this.drawnData = [];
    }
  }

  onMouseLeave(e) {
    if (this.drawingIsHappening) {
      this.drawingIsHappening = false;
      this.props.drawHandler(this.drawnData);
      if (
        !this.props.drawingHasBeenMadeOnChart &&
        this.drawnData.length !== 0
      ) {
        this.props.setDrawingState();
      }
      this.instance.series[2].setData([], false);
      this.drawnData = [];
    }
  }

  onWheel(e) {
    let currentMin = this.instance.yAxis[0].min;
    let currentMax = this.instance.yAxis[0].max;

    let oldYmax = currentMax;
    let oldYmin = currentMin;
    if (e.nativeEvent.wheelDelta < 0) {
      if (currentMax < 25) {
        if (20 - currentMax > 0.25) {
          this.instance.yAxis[0].update({
            max: currentMax + 0.25
          });
          oldYmax = currentMax + 0.25;
        } else {
          this.instance.yAxis[0].update({
            max: 25
          });
          oldYmax = 25;
        }
      }

      if (currentMin > 0) {
        if (currentMin > 0.1) {
          this.instance.yAxis[0].update({
            min: currentMin - 0.1
          });
          oldYmin = currentMin - 0.1;
        } else {
          this.instance.yAxis[0].update({
            min: 0
          });
          oldYmin = 0;
        }
      }
    } else {
      let startingYmax = Math.max(
        this.props.dataBaseMax +
          (this.props.dataBaseMax - this.props.dataBaseMin) * 0.05,
        this.props.dataRealMax +
          (this.props.dataRealMax - this.props.dataRealMin) * 0.05
      );
      let startingYmin = Math.min(
        this.props.dataBaseMin -
          (this.props.dataBaseMax - this.props.dataBaseMin) * 0.05,
        this.props.dataRealMin -
          (this.props.dataRealMax - this.props.dataRealMin) * 0.05
      );

      if (currentMax > startingYmax) {
        if (currentMax - startingYmax > 0.25) {
          this.instance.yAxis[0].update({
            max: currentMax - 0.25
          });
          oldYmax = currentMax - 0.25;
        } else {
          this.instance.yAxis[0].update({
            max: startingYmax
          });
          oldYmax = startingYmax;
        }
      }

      if (currentMin < startingYmin) {
        if (startingYmin - currentMin > 0.1) {
          this.instance.yAxis[0].update({
            min: currentMin + 0.1
          });
          oldYmin = currentMin + 0.1;
        } else {
          this.instance.yAxis[0].update({
            min: startingYmin
          });
          oldYmin = startingYmin;
        }
      }
    }
    this.props.updateOldYminmax(this.props.seriesIndex, oldYmin, oldYmax);
  }

  render() {
    return (
      <div>
        <div
          id="containerMacroChart"
          onMouseDown={this.onMouseDown.bind(this)}
          onMouseMove={this.onMouseMove.bind(this)}
          onMouseUp={this.onMouseUp.bind(this)}
          onMouseLeave={this.onMouseLeave.bind(this)}
          onWheel={this.onWheel.bind(this)}
        ></div>
      </div>
    );
  }
}

export default MacroChart;
