import React from "react";
import MacroChart from "./charts/MacroChart.js";
import MacroTabs from "./widgets/MacroTabs.js";
import macrojson from "./json/MacroJson.js";

import ClearIcon from "@material-ui/icons/Clear";
import ZoomOutIcon from "@material-ui/icons/ZoomOut";
import TimelineIcon from "@material-ui/icons/Timeline";
import IconButton from "@material-ui/core/IconButton";
import BrushIcon from "@material-ui/icons/Brush";
import CachedIcon from "@material-ui/icons/Cached";
import { withStyles } from "@material-ui/core/styles";

var linear = require("everpolate").linear;

class MacroToolBox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      seriesIndex: 0,
      drawingRegime: false,
      currentDataBase: macrojson.ZCY.dataBase,
      currentDataReal: macrojson.ZCY.dataReal,
      chartsAreZoomed: false,
      drawChangesHasBeenMade: [false, false, false, false, false]
    };
    this.oldYminmax = [
      [undefined, undefined],
      [undefined, undefined],
      [undefined, undefined],
      [undefined, undefined],
      [undefined, undefined]
    ];
    this.xExtremes = this.getExtremes(macrojson.MIR.dataReal, 0);
    this.xExtremesZCY = this.getExtremes(macrojson.ZCY.dataReal, 0);
  }

  setDrawingState() {
    let list = this.state.drawChangesHasBeenMade.slice();
    list[this.state.seriesIndex] = this.state.drawChangesHasBeenMade[
      this.state.seriesIndex
    ]
      ? false
      : true;
    this.setState({ drawChangesHasBeenMade: list });
  }

  changeZoomState() {
    this.setState({
      chartsAreZoomed: this.state.chartsAreZoomed ? false : true
    });
  }

  updateOldYminmax(index, oldYmin, oldYmax) {
    this.oldYminmax[index][0] = oldYmin;
    this.oldYminmax[index][1] = oldYmax;
  }

  setXminmax(min, max) {
    if (this.state.seriesIndex !== 0) {
      this.xExtremes = [min, max];
    }
  }

  drawHandler(seriesDrawn) {
    let series = undefined;
    if (this.state.seriesIndex === 0) {
      series = macrojson.ZCY.dataReal;
    } else if (this.state.seriesIndex === 1) {
      series = macrojson.SPT.dataReal;
    } else if (this.state.seriesIndex === 2) {
      series = macrojson.MS6.dataReal;
    } else if (this.state.seriesIndex === 3) {
      series = macrojson.MIR.dataReal;
    } else if (this.state.seriesIndex === 4) {
      series = macrojson.HPI.dataReal;
    }

    let xSeriesDrawn = [];
    let ySeriesDrawn = [];
    for (var i = 0; i < seriesDrawn.length; i++) {
      xSeriesDrawn.push(seriesDrawn[i][0]);
      ySeriesDrawn.push(seriesDrawn[i][1]);
    }

    let xLeftDrawn = xSeriesDrawn[0];
    let xRightDrawn = xSeriesDrawn[seriesDrawn.length - 1];
    let xInterpolate = [];
    let indecesToBeChanged = [];
    for (var j = 0; j < series.length; j++) {
      if (series[j][0] >= xLeftDrawn && series[j][0] <= xRightDrawn) {
        xInterpolate.push(series[j][0]);
        indecesToBeChanged.push(j);
      }
    }

    let yInterpolate = linear(xInterpolate, xSeriesDrawn, ySeriesDrawn);
    let drawnBlock = [];
    for (var k = 0; k < xInterpolate.length; k++) {
      drawnBlock.push([xInterpolate[k], yInterpolate[k]]);
    }

    // console.log(xInterpolate)
    let count = 0;
    for (const index of indecesToBeChanged) {
      series[index] = drawnBlock[count];
      ++count;
    }

    if (this.state.seriesIndex === 0) {
      macrojson.ZCY.dataReal = series;
    } else if (this.state.seriesIndex === 1) {
      macrojson.SPT.dataReal = series;
    } else if (this.state.seriesIndex === 2) {
      macrojson.MS6.dataReal = series;
    } else if (this.state.seriesIndex === 3) {
      macrojson.MIR.dataReal = series;
    } else if (this.state.seriesIndex === 4) {
      macrojson.HPI.dataReal = series;
    }

    this.setState({
      currentDataReal: series
    });
  }

  changeTab(index) {
    let base = undefined;
    let real = undefined;

    if (index === 0) {
      base = macrojson.ZCY.dataBase;
      real = macrojson.ZCY.dataReal;
    } else if (index === 1) {
      base = macrojson.SPT.dataBase;
      real = macrojson.SPT.dataReal;
    } else if (index === 2) {
      base = macrojson.MS6.dataBase;
      real = macrojson.MS6.dataReal;
    } else if (index === 3) {
      base = macrojson.MIR.dataBase;
      real = macrojson.MIR.dataReal;
    } else if (index === 4) {
      base = macrojson.HPI.dataBase;
      real = macrojson.HPI.dataReal;
    }

    this.setState({
      seriesIndex: index,
      currentDataBase: base,
      currentDataReal: real
    });
  }

  changeTabInterface = {
    onChangeTab: this.changeTab.bind(this)
  };

  chooseRegime() {
    if (this.state.drawingRegime) {
      this.setState({ drawingRegime: false });
    } else {
      this.setState({ drawingRegime: true });
    }
  }

  cancelZoom() {
    if (this.state.chartsAreZoomed) {
      this.xExtremes = this.getExtremes(macrojson.MIR.dataReal, 0);
      this.changeZoomState();
      this.setState({ seriesIndex: this.state.seriesIndex });
    }
  }

  cancelDraw() {
    let real = undefined;

    if (this.state.seriesIndex === 0) {
      macrojson.ZCY.dataReal = [...macrojson.ZCY.dataBase];
      real = macrojson.ZCY.dataReal;
    } else if (this.state.seriesIndex === 1) {
      macrojson.SPT.dataReal = [...macrojson.SPT.dataBase];
      real = macrojson.SPT.dataReal;
    } else if (this.state.seriesIndex === 2) {
      macrojson.MS6.dataReal = [...macrojson.MS6.dataBase];
      real = macrojson.MS6.dataReal;
    } else if (this.state.seriesIndex === 3) {
      macrojson.MIR.dataReal = [...macrojson.MIR.dataBase];
      real = macrojson.MIR.dataReal;
    } else if (this.state.seriesIndex === 4) {
      macrojson.HPI.dataReal = [...macrojson.HPI.dataBase];
      real = macrojson.HPI.dataReal;
    }

    this.setState({
      currentDataReal: real
    });

    this.setDrawingState();
  }

  getExtremes(data, axis) {
    let series = [];
    for (var i = 0; i < data.length; i++) {
      series.push(data[i][axis]);
    }

    var min = Math.min.apply(null, series);
    var max = Math.max.apply(null, series);

    return [min, max];
  }

  render() {
    let cancelZoomButton = undefined;
    let cancelDrawButton = undefined;
    let changeRegimeButton = undefined;
    let newSimulationButton = undefined;

    if (this.state.chartsAreZoomed && this.state.seriesIndex !== 0) {
      cancelZoomButton = (
        <CancelZoomButton onClick={this.cancelZoom.bind(this)}>
          <ZoomOutIcon />
        </CancelZoomButton>
      );
    }

    if (this.state.drawChangesHasBeenMade[this.state.seriesIndex]) {
      cancelDrawButton = (
        <CancelDrawButton onClick={this.cancelDraw.bind(this)}>
          <ClearIcon />
        </CancelDrawButton>
      );
    }

    if (this.state.drawingRegime) {
      changeRegimeButton = (
        <ChangeRegimeButton onClick={this.chooseRegime.bind(this)}>
          <TimelineIcon />
        </ChangeRegimeButton>
      );
    } else {
      changeRegimeButton = (
        <ChangeRegimeButton onClick={this.chooseRegime.bind(this)}>
          <BrushIcon />
        </ChangeRegimeButton>
      );
    }

    if (this.state.seriesIndex !== 0) {
      newSimulationButton = (
        <NewSimulationButton
          aria-label="delete"
          theme={{ root: { right: "20%" } }}
        >
          <CachedIcon />
        </NewSimulationButton>
      );
    }

    return (
      <div className="MacroToolBox">
        <MacroTabs interface={this.changeTabInterface} />
        <MacroChart
          seriesIndex={this.state.seriesIndex}
          drawingRegime={this.state.drawingRegime}
          dataBase={this.state.currentDataBase}
          dataReal={this.state.currentDataReal}
          drawHandler={this.drawHandler.bind(this)}
          dataBaseMin={this.getExtremes(this.state.currentDataBase, 1)[0]}
          dataBaseMax={this.getExtremes(this.state.currentDataBase, 1)[1]}
          dataRealMin={this.getExtremes(this.state.currentDataReal, 1)[0]}
          dataRealMax={this.getExtremes(this.state.currentDataReal, 1)[1]}
          oldYmin={this.oldYminmax[this.state.seriesIndex][0]}
          oldYmax={this.oldYminmax[this.state.seriesIndex][1]}
          xMin={
            this.state.seriesIndex === 0
              ? this.xExtremesZCY[0]
              : this.xExtremes[0]
          }
          xMax={
            this.state.seriesIndex === 0
              ? this.xExtremesZCY[1]
              : this.xExtremes[1]
          }
          updateOldYminmax={this.updateOldYminmax.bind(this)}
          setXminmax={this.setXminmax.bind(this)}
          chartsAreZoomed={this.state.chartsAreZoomed}
          changeZoomState={this.changeZoomState.bind(this)}
          drawingHasBeenMadeOnChart={
            this.state.drawChangesHasBeenMade[this.state.seriesIndex]
          }
          setDrawingState={this.setDrawingState.bind(this)}
        />

        <div className="mainMacroChartButtons">
          {changeRegimeButton}
          {newSimulationButton}
        </div>

        <div className="addMacroChartButtons">
          {cancelZoomButton}
          {cancelDrawButton}
        </div>
      </div>
    );
  }
}

export default MacroToolBox;

const NewSimulationButton = withStyles({
  root: {
    color: "#00BD32",
    padding: 2
  }
})(IconButton);

const ChangeRegimeButton = withStyles({
  root: {
    color: "#DF4F4F",
    padding: 2
  }
})(IconButton);

const CancelZoomButton = withStyles({
  root: {
    padding: 2,
    color: "#00753E",
    display: "block"
  }
})(IconButton);

const CancelDrawButton = withStyles({
  root: {
    padding: 2,
    color: "#00753E",
    display: "block"
  }
})(IconButton);
